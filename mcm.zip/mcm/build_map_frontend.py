map_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Distribution Map - Meal Connect</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Outfit:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ url_for('static', filename='css/home.css') }}">
    
    <!-- Leaflet & Plugins -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.3/MarkerCluster.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.3/MarkerCluster.Default.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.css" />
    
    <script src="{{ url_for('static', filename='js/theme.js') }}"></script>
    <style>
      body { display: flex; height: 100vh; overflow: hidden; background: var(--bg-color); }
      .sidebar { width: 280px; background: rgba(6, 11, 8, 0.95); border-right: 1px solid var(--surface-border); padding: 2rem; display: flex; flex-direction: column; z-index: 1000; flex-shrink: 0; }
      .sidebar-logo { margin-bottom: 3rem; font-size: 1.5rem; }
      .nav-menu { list-style: none; display: flex; flex-direction: column; gap: 0.5rem; flex-grow: 1; }
      .nav-item { padding: 1rem; border-radius: 12px; color: var(--text-muted); text-decoration: none; display: flex; align-items: center; gap: 1rem; transition: var(--transition); font-weight: 500; }
      .nav-item:hover, .nav-item.active { background: rgba(46,204,113,0.1); color: var(--primary); }
      
      .main-content { flex-grow: 1; display: flex; flex-direction: column; position: relative; overflow: hidden; }
      
      .top-bar { 
          display: flex; justify-content: space-between; align-items: center; 
          padding: 1.5rem 2rem; border-bottom: 1px solid var(--surface-border); background: var(--surface-color); z-index: 10;
      }
      
      .map-layout { display: flex; flex-grow: 1; overflow: hidden; position: relative; }
      #map { flex-grow: 1; height: 100%; z-index: 1; background: #222; }
      
      /* Control Panel */
      .control-panel {
          position: absolute; top: 1rem; right: 1rem; width: 320px; z-index: 1000;
          background: var(--surface-color); border: 1px solid var(--surface-border);
          border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.2); padding: 1rem;
          max-height: calc(100vh - 120px); overflow-y: auto; backdrop-filter: blur(10px);
      }
      
      /* Legend */
      .legend {
          position: absolute; bottom: 2rem; left: 1rem; z-index: 1000;
          background: rgba(6, 11, 8, 0.9); border: 1px solid var(--surface-border);
          border-radius: 8px; padding: 1rem; font-size: 0.85rem; backdrop-filter: blur(5px);
      }
      .legend-item { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem; }
      
      /* Custom Markers */
      .custom-marker { display: flex; justify-content: center; align-items: center; width: 36px; height: 36px; border-radius: 50%; color: white; font-size: 1.2rem; box-shadow: 0 4px 10px rgba(0,0,0,0.3); border: 2px solid white; }
      .marker-hotel { background: #f39c12; }
      .marker-ngo { background: #2ecc71; }
      .marker-me { background: #3498db; width: 44px; height: 44px; font-size: 1.5rem; animation: pulse-blue 2s infinite; }
      .marker-alert { animation: pulse-red 1.5s infinite; border-color: #e74c3c; }
      
      @keyframes pulse-blue {
          0% { box-shadow: 0 0 0 0 rgba(52, 152, 219, 0.7); }
          70% { box-shadow: 0 0 0 15px rgba(52, 152, 219, 0); }
          100% { box-shadow: 0 0 0 0 rgba(52, 152, 219, 0); }
      }
      @keyframes pulse-red {
          0% { box-shadow: 0 0 0 0 rgba(231, 76, 60, 0.8); }
          70% { box-shadow: 0 0 0 20px rgba(231, 76, 60, 0); }
          100% { box-shadow: 0 0 0 0 rgba(231, 76, 60, 0); }
      }
      
      /* Popups & Tooltips */
      .leaflet-popup-content-wrapper { background: var(--surface-color); color: var(--text-color); border: 1px solid var(--surface-border); border-radius: 12px; }
      .leaflet-popup-tip { background: var(--surface-color); }
      .leaflet-tooltip { background: rgba(0,0,0,0.7); border: none; color: white; font-weight: 500; font-family: var(--font-body); border-radius: 4px; box-shadow: none; }
      .leaflet-tooltip-left::before, .leaflet-tooltip-right::before { border-color: transparent; }
      
      .popup-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 0.5rem; }
      .popup-title { font-size: 1.1rem; font-family: var(--font-display); font-weight: 600; margin: 0; color: #fff; }
      .badge-gold { background: linear-gradient(45deg, #f1c40f, #f39c12); color: #000; padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; font-weight: bold; }
      .popup-body { font-size: 0.9rem; line-height: 1.4; color: var(--text-muted); }
      .popup-actions { display: flex; gap: 0.5rem; margin-top: 1rem; }
      
      /* Nearest Panel */
      .nearest-panel { margin-top: 1rem; border-top: 1px solid var(--surface-border); padding-top: 1rem; }
      .nearest-card { background: rgba(255,255,255,0.05); padding: 0.8rem; border-radius: 8px; margin-bottom: 0.5rem; cursor: pointer; transition: 0.2s; border: 1px solid transparent; }
      .nearest-card:hover { background: rgba(46,204,113,0.1); border-color: var(--primary); }
      .card-title { display: flex; justify-content: space-between; font-weight: 600; color: #fff; }
      
      /* Filters */
      .filter-group { margin-bottom: 1rem; }
      .filter-label { display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-size: 0.9rem; color: var(--text-muted); margin-bottom: 0.5rem; }
      
      /* Mobile */
      @media (max-width: 768px) {
          body { flex-direction: column; }
          .sidebar { display: none; }
          .control-panel { 
              top: auto; bottom: 0; right: 0; width: 100%; border-radius: 20px 20px 0 0; 
              max-height: 50vh; padding-bottom: 2rem; border-bottom: none; border-right: none; border-left: none;
          }
          .legend { display: none; }
      }
    </style>
</head>
<body>
    <div class="sidebar glass">
      <a href="{{ url_for('index') }}" class="sidebar-logo nav-logo" style="text-decoration:none; color:inherit; display:flex; align-items:center;">
        <i class="ri-leaf-line" style="margin-right: 8px;"></i> Meal Connect
      </a>
      <ul class="nav-menu">
        <a href="{{ url_for('dashboard') }}" class="nav-item"><i class="ri-dashboard-line"></i> Dashboard</a>
        <a href="{{ url_for('food_entry') }}" class="nav-item"><i class="ri-edit-box-line"></i> Daily Entry</a>
        <a href="{{ url_for('prediction') }}" class="nav-item"><i class="ri-line-chart-line"></i> Prediction</a>
        <a href="{{ url_for('alerts') }}" class="nav-item"><i class="ri-notification-badge-line"></i> Pending Alerts</a>
        <a href="{{ url_for('live_map') }}" class="nav-item active"><i class="ri-map-pin-line"></i> Live Map</a>
        <a href="{{ url_for('history') }}" class="nav-item"><i class="ri-history-line"></i> History</a>
        <a href="{{ url_for('analytics') }}" class="nav-item"><i class="ri-bar-chart-2-line"></i> Analytics</a>
        <a href="{{ url_for('profile') }}" class="nav-item"><i class="ri-settings-4-line"></i> Settings</a>
        <a href="{{ url_for('logout') }}" class="btn btn-outline" style="width: 100%; border-color: rgba(231,76,60,0.5); color: #ff6b6b; margin-top: auto;">
          <i class="ri-logout-box-r-line"></i> Logout
        </a>
      </ul>
    </div>

    <div class="main-content">
      <div class="top-bar">
        <div class="hotel-info">
          <h1 style="font-size: 1.5rem; margin: 0;">Live Distribution Map</h1>
          <span style="font-size: 0.85rem; color: var(--text-muted);"><i class="ri-building-line"></i> {{ session.get('hotel_id', '') }}</span>
        </div>
        <div style="display: flex; gap: 1rem;">
            <button id="theme-toggle" class="btn btn-outline btn-sm" style="border:none; font-size:1.2rem; padding:0.5rem;" title="Toggle Theme">
              <i id="theme-toggle-icon" class="ri-moon-line"></i>
            </button>
        </div>
      </div>

      <div class="map-layout">
        <div id="map"></div>
        
        <div class="control-panel glass">
            <div class="filter-group">
                <div style="position:relative;">
                    <input type="text" id="searchInput" class="form-input" placeholder="Search NGO or Hotel..." style="padding-left: 2.5rem; background:rgba(0,0,0,0.2);">
                    <i class="ri-search-line" style="position:absolute; left:0.8rem; top:0.8rem; color:var(--text-muted);"></i>
                </div>
            </div>
            
            <div class="filter-group" style="display:flex; gap:0.5rem;">
                <button class="btn btn-primary btn-sm" id="btn-locate" style="flex-grow:1;"><i class="ri-focus-3-line"></i> Locate Me</button>
                <button class="btn btn-outline btn-sm" id="btn-reset" title="Reset View"><i class="ri-refresh-line"></i></button>
                <button class="btn btn-outline btn-sm" id="btn-clear-route" title="Clear Route" style="display:none; border-color:#e74c3c; color:#e74c3c;"><i class="ri-route-line"></i> Clear</button>
            </div>
            
            <div class="filter-group">
                <h4 style="margin-bottom:0.5rem; color:#fff;">Filters</h4>
                <label class="filter-label"><input type="checkbox" id="filter-ngos" checked> Show NGOs</label>
                <label class="filter-label"><input type="checkbox" id="filter-hotels" checked> Show Hotels</label>
                <label class="filter-label"><input type="checkbox" id="filter-alerts"> Active Alerts Only</label>
            </div>
            
            <div class="filter-group">
                <h4 style="margin-bottom:0.5rem; color:#fff;">Search Radius: <span id="radius-val">10</span> km</h4>
                <input type="range" id="radius-slider" min="1" max="50" value="10" style="width:100%;">
            </div>
            
            <div class="nearest-panel" id="nearest-panel">
                <h4 style="margin-bottom:1rem; color:#fff;">Nearest Approved NGOs</h4>
                <div id="nearest-list">Loading...</div>
            </div>
        </div>
        
        <div class="legend glass">
            <div class="legend-item"><div class="custom-marker marker-me" style="width:24px; height:24px; font-size:0.8rem; animation:none;"><i class="ri-building-2-fill"></i></div> My Hotel</div>
            <div class="legend-item"><div class="custom-marker marker-hotel" style="width:24px; height:24px; font-size:0.8rem;"><i class="ri-hotel-fill"></i></div> Other Hotel</div>
            <div class="legend-item"><div class="custom-marker marker-ngo" style="width:24px; height:24px; font-size:0.8rem;"><i class="ri-heart-3-fill"></i></div> NGO</div>
            <div class="legend-item"><div class="custom-marker marker-hotel marker-alert" style="width:24px; height:24px; font-size:0.8rem;"><i class="ri-hotel-fill"></i></div> Active Alert (Pulsing)</div>
        </div>
      </div>
    </div>

    <!-- Leaflet & Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.3/leaflet.markercluster.js"></script>
    <script src="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', async () => {
            const mapContainer = document.getElementById('map');
            let map, markers, routeControl, radiusCircle;
            let myHotel = null;
            let allNGOs = [];
            let currentLayer = 'dark';
            
            // Tiles
            const tiles = {
                light: L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', { attribution: '© OpenStreetMap, © CartoDB' }),
                dark: L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { attribution: '© OpenStreetMap, © CartoDB' })
            };

            // Icons
            const createIcon = (type, isMe, hasAlert) => {
                let iconClass = 'ri-map-pin-fill';
                let bgClass = 'marker-hotel';
                if (type === 'NGO') { iconClass = 'ri-heart-3-fill'; bgClass = 'marker-ngo'; }
                if (type === 'Hotel') { iconClass = 'ri-hotel-fill'; }
                
                let extraClass = '';
                if (isMe) { bgClass = 'marker-me'; iconClass = 'ri-building-2-fill'; }
                else if (hasAlert) { extraClass = 'marker-alert'; }
                
                return L.divIcon({
                    html: `<div class="custom-marker ${bgClass} ${extraClass}"><i class="${iconClass}"></i></div>`,
                    className: 'custom-div-icon',
                    iconSize: [36, 36],
                    iconAnchor: [18, 18],
                    popupAnchor: [0, -18]
                });
            };

            try {
                const response = await fetch('/api/map_data');
                if (!response.ok) throw new Error("API Error " + response.status);
                const data = await response.json();
                
                myHotel = data.hotel;
                allNGOs = data.ngos;
                
                const center = (myHotel && myHotel.lat) ? [myHotel.lat, myHotel.lon] : [20.5937, 78.9629];
                map = L.map('map').setView(center, 13);
                
                // Set initial tile based on theme
                const isDark = document.body.classList.contains('light-theme') ? false : true;
                tiles[isDark ? 'dark' : 'light'].addTo(map);
                
                // Clustering
                markers = L.markerClusterGroup({
                    maxClusterRadius: 40,
                    spiderfyOnMaxZoom: true,
                    polygonOptions: { fillOpacity: 0.2, color: '#2ecc71', weight: 1 }
                });
                
                const layerRefs = [];

                // Draw My Hotel
                if (myHotel && myHotel.lat) {
                    const m = L.marker([myHotel.lat, myHotel.lon], { icon: createIcon('Hotel', true, false), zIndexOffset: 1000 })
                        .bindPopup(`
                            <div class="popup-header">
                                <h3 class="popup-title">My Hotel: ${myHotel.name}</h3>
                                <span class="badge-gold">${myHotel.badge}</span>
                            </div>
                            <div class="popup-body">
                                <div><i class="ri-restaurant-line"></i> Total Donated: ${myHotel.total_donated} kg</div>
                                <div><i class="ri-map-pin-line"></i> ${myHotel.address || 'Address missing'}</div>
                            </div>
                        `)
                        .bindTooltip(myHotel.name, { permanent: true, direction: 'bottom', offset: [0, 15] });
                    
                    markers.addLayer(m);
                    layerRefs.push({ type: 'me', data: myHotel, layer: m });
                    
                    // Draw Radius
                    radiusCircle = L.circle([myHotel.lat, myHotel.lon], {
                        radius: 10000, // 10km initial
                        color: '#3498db', weight: 1, fillOpacity: 0.05, dashArray: '5, 5'
                    }).addTo(map);
                }

                // Draw NGOs
                allNGOs.forEach(ngo => {
                    const m = L.marker([ngo.lat, ngo.lon], { icon: createIcon('NGO', false, false) })
                        .bindPopup(`
                            <div class="popup-header">
                                <h3 class="popup-title">${ngo.name}</h3>
                                <span style="color:var(--primary); font-weight:bold;"><i class="ri-star-fill"></i> ${ngo.rating}</span>
                            </div>
                            <div class="popup-body">
                                <div><i class="ri-user-line"></i> ${ngo.contact_person}</div>
                                <div><i class="ri-phone-line"></i> <a href="tel:${ngo.phone}" style="color:var(--primary)">${ngo.phone}</a></div>
                                <div><i class="ri-mail-line"></i> ${ngo.email}</div>
                                <div style="margin-top:0.5rem; padding-top:0.5rem; border-top:1px solid rgba(255,255,255,0.1);">
                                    <i class="ri-truck-line"></i> ${ngo.distance_km} km away (~${ngo.eta_mins} mins)
                                </div>
                            </div>
                            <div class="popup-actions">
                                <button class="btn btn-primary btn-sm route-btn" data-lat="${ngo.lat}" data-lon="${ngo.lon}" style="flex:1;">Get Directions</button>
                                <a href="/alerts" class="btn btn-outline btn-sm" style="flex:1;">Send Alert</a>
                            </div>
                        `)
                        .bindTooltip(ngo.name, { permanent: true, direction: 'bottom', offset: [0, 15] });
                    
                    markers.addLayer(m);
                    layerRefs.push({ type: 'ngo', data: ngo, layer: m });
                });

                map.addLayer(markers);
                
                // Hide tooltips on zoom out
                map.on('zoomend', () => {
                    const z = map.getZoom();
                    document.querySelectorAll('.leaflet-tooltip').forEach(el => {
                        el.style.opacity = z < 12 ? '0' : '1';
                        el.style.pointerEvents = z < 12 ? 'none' : 'auto';
                    });
                });
                
                // Render Nearest List
                const renderNearest = () => {
                    const list = document.getElementById('nearest-list');
                    if (!myHotel || !myHotel.lat) { list.innerHTML = 'Location not set.'; return; }
                    
                    const sorted = allNGOs.slice(0, 3);
                    list.innerHTML = sorted.map((n, i) => `
                        <div class="nearest-card" onclick="flyToNgo(${n.lat}, ${n.lon})">
                            <div class="card-title">
                                <span>${i===0 ? '<i class="ri-medal-fill" style="color:#f1c40f"></i> ' : ''}${n.name}</span>
                                <span style="color:var(--primary); font-size:0.85rem;">${n.distance_km} km</span>
                            </div>
                            <div style="color:var(--text-muted); font-size:0.8rem; margin-top:0.2rem;"><i class="ri-time-line"></i> ETA: ${n.eta_mins} mins</div>
                        </div>
                    `).join('');
                };
                renderNearest();

                // Fly function for window scope
                window.flyToNgo = (lat, lon) => {
                    map.flyTo([lat, lon], 16);
                };

                // Routing
                document.addEventListener('click', (e) => {
                    if (e.target && e.target.classList.contains('route-btn')) {
                        if (!myHotel || !myHotel.lat) return alert("Your hotel location is missing.");
                        const lat = e.target.getAttribute('data-lat');
                        const lon = e.target.getAttribute('data-lon');
                        
                        if (routeControl) map.removeControl(routeControl);
                        
                        routeControl = L.Routing.control({
                            waypoints: [ L.latLng(myHotel.lat, myHotel.lon), L.latLng(lat, lon) ],
                            routeWhileDragging: false,
                            showAlternatives: false,
                            addWaypoints: false,
                            lineOptions: { styles: [{color: '#3498db', weight: 4}] },
                            createMarker: function() { return null; } // Don't add extra markers
                        }).addTo(map);
                        
                        document.getElementById('btn-clear-route').style.display = 'block';
                    }
                });

                document.getElementById('btn-clear-route').addEventListener('click', () => {
                    if (routeControl) { map.removeControl(routeControl); routeControl = null; }
                    document.getElementById('btn-clear-route').style.display = 'none';
                });
                
                // Controls
                document.getElementById('btn-locate').addEventListener('click', () => {
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(pos => {
                            map.flyTo([pos.coords.latitude, pos.coords.longitude], 15);
                        }, () => {
                            if (myHotel && myHotel.lat) map.flyTo([myHotel.lat, myHotel.lon], 15);
                        });
                    }
                });
                
                document.getElementById('btn-reset').addEventListener('click', () => {
                    const bounds = L.latLngBounds([ [myHotel.lat, myHotel.lon] ]);
                    allNGOs.forEach(n => bounds.extend([n.lat, n.lon]));
                    map.fitBounds(bounds, { padding: [50, 50] });
                });
                
                const updateFilters = () => {
                    const showNGOs = document.getElementById('filter-ngos').checked;
                    const rad = parseInt(document.getElementById('radius-slider').value);
                    
                    if(radiusCircle) radiusCircle.setRadius(rad * 1000);
                    
                    markers.clearLayers();
                    layerRefs.forEach(ref => {
                        if (ref.type === 'me') { markers.addLayer(ref.layer); return; }
                        if (ref.type === 'ngo' && !showNGOs) return;
                        if (ref.data.distance_km > rad) return;
                        markers.addLayer(ref.layer);
                    });
                };
                
                document.getElementById('filter-ngos').addEventListener('change', updateFilters);
                document.getElementById('radius-slider').addEventListener('input', (e) => {
                    document.getElementById('radius-val').innerText = e.target.value;
                    updateFilters();
                });

            } catch (err) {
                mapContainer.innerHTML = `<div style="padding:2rem; color:#ff6b6b; font-family:var(--font-body);"><h3>Map Initialization Error</h3><p>${err.message}</p></div>`;
            }
        });
    </script>
</body>
</html>
"""

with open('templates/map.html', 'w', encoding='utf-8') as f:
    f.write(map_html)
